function [Z,N,M,E] = SRAG(X,Z_ini,c,lambda1,lambda2,max_iter,Ctg)
% 
[m,n] = size(X);
% ---------- Initilization -------- %
miu = 0.01;
rho = 1.5;
max_miu = 1e8;
tol  = 1e-5;
tol2 = 1e-2;
zr   = 1e-9;
Y1 = zeros(m,n);
Y2 = zeros(n,n);
Y3 = zeros(n,n);
E  = zeros(m,n);

distX = L2_distance_1(X,X);
for iter = 1:max_iter
    if iter == 1
        Z = Z_ini;
        N = Z_ini;
        M = Z_ini;
        clear Z_ini F_ini
    end
    N_old = N;
    M_old = M;
    Z_old = Z;
    E_old = E;
    % -------- Update Z --------- %
    Z = Ctg*(X'*(X-E+Y1/miu)+N+M-(Y2+Y3)/miu);
    Z = Z- diag(diag(Z));
    % -------- Update N --------- %
    dist  = distX;                   
    N     = Z+(Y2-dist)/miu;
    N     = N - diag(diag(N));
    for ic = 1:n
        idx    = 1:n;
        idx(ic) = [];
        N(ic,idx) = EProjSimplex_new(N(ic,idx));          % 
    end
    % -------- Update M --------- %
    tempM1 = Z+Y3/miu;
    tempM2 = lambda1/miu;
    M = max(0,tempM1-tempM2) + min(0,tempM1+tempM2);
    % ------- Update E ---------- %
    temp1 = X-X*Z+Y1/miu;
    temp2 = lambda2/miu;  
    E = max(0,temp1-temp2) + min(0,temp1+temp2);   
    % -------- Update Y1 Y2 Y3 miu -------- %
    L1 = X-X*Z-E;
    L2 = Z-N;
    L3 = Z-M;
    Y1 = Y1+miu*L1;
    Y2 = Y2+miu*L2;
    Y3 = Y3+miu*L3;
    
    LL1 = norm(Z-Z_old,'fro');
    LL2 = norm(N-N_old,'fro');
    LL3 = norm(M-M_old,'fro');
    LL4 = norm(E-E_old,'fro');
    SLSL = max(max(max(LL1,LL2),LL3),LL4)/norm(X,'fro');
    if miu*SLSL < tol2
        miu = min(rho*miu,max_miu);
    end
    % --------- obj ---------- %
    leq1 = max(max(abs(L1(:))),max(abs(L2(:))));
    stopC = max(leq1,max(abs(L3(:))));
    if stopC < tol
        iter
        break;
    end   
end
end